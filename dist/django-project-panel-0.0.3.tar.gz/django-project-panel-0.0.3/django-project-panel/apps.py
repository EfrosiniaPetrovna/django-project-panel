from django.apps import AppConfig


class ProjectPanelAppConfig(AppConfig):
    default_auto_field = 'django.db.models.BigAutoField'
    name = 'project_panel_app'
